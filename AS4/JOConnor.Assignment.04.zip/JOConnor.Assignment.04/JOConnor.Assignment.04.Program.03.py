import interface as bj


def main():
    bj.gameLoop()


main()
