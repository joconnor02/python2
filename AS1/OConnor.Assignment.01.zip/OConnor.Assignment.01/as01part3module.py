
def metersToFeet(meters):
    feet = float(meters) / 0.3048
    return feet

def feetToMeters(feet):
    meters = float(feet) * 0.3048
    return meters



